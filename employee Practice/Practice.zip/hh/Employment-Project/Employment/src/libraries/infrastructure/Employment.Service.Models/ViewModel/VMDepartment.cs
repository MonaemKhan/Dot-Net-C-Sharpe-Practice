﻿using Employment.Sheared.Common;

namespace Employment.Service.Models.ViewModel;

public class VMDepartment:IVM
{
	public int Id { get; set; }
	public string DepartmentName { get; set; } = string.Empty;

	
	
}
