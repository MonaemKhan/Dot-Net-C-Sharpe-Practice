﻿namespace Employment.Core;

public interface ICore
{
}
