﻿namespace Employment.Sheared.Enums;

public enum EntityStatus
{
	Created = 1,
	Updated = 2,
	Deleted = 3
}
