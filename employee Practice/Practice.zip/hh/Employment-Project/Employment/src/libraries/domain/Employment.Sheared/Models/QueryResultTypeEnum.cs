﻿namespace Employment.Sheared.Models;

public enum QueryResultTypeEnum
{
	Success,
	InvalidInput,
	UnprocessableEntity,
	NotFound
}
