﻿namespace EmployeeModel
{
    public class Class1
    {

    }
}