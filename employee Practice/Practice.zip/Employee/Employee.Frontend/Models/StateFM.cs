﻿namespace Employee.Frontend.Models;

public class StateFM
{
    public int Id { get; set; }
    public string StateName { get; set; }
    public int CountryId { get; set; }
    public string? CountryName { get; set; }
}
