﻿namespace Employee.Frontend.Models;

public class CountryFM
{
    public int Id { get; set; }
    public string? CountryName { get; set; }
    public string? Courencies { get; set; }
}
